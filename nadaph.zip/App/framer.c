/*--------------------------------framer.c------------------------*/
/*
Written by:	George Cheney
		16.472 / 16.572 Embedded Real Time Systems
		Electrical and Computer Engineering Dept.
		UMASS Lowell
Edited by: Zubair Nadaph

PURPOSE
Get buffers from the output queue, and empty them to the USART2 Tx.

INPUT PARAMETERS
data 		--	task data pointer (not used)

GLOBALS
outputQueue	-- Provides full buffers from the robot ctl task.

CHANGES
03-24-2011  - Release to class.
*/
#include "includes.h"
#include "assert.h"
#include "PBuffer.h"
#include "Globals.h"
#include "SerIODriver.h"
#include "MemMgr.h"
#include "PktParser.h"
#include "framer.h"

/*----- c o n s t a n t    d e f i n i t i o n s -----*/

/* Size of the stacks for the Output task */
#define	FRAMER_STK_SIZE     256 
#define zero 0

// Output Tasb Control Block
OS_TCB framerTCB;

Framer *framer;

/* Allocate Output Task stack space */
CPU_STK			framerStk[FRAMER_STK_SIZE];

/*----- f u n c t i o n    p r o t o t y p e s -----*/
void Output (void *data);

/*--------------- C r e a t e O u t p u t T a s k ( ) ---------------*/

void CreateFramerTask(void)
{
	OS_ERR osErr;/* -- uCos Error Code */   
        
        //OSQCreate(&framerQueue, "framer Queue", PoolSize, &osErr);
	//assert(osErr == OS_ERR_NONE);

	/* Create framer task. */	
  OSTaskCreate(&framerTCB,
               "Framer Task",
               Output, 
               NULL,
               framerPrio,
               &framerStk[0],
               FRAMER_STK_SIZE / 10,
               FRAMER_STK_SIZE,
               0,
               0,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);
  assert(osErr == OS_ERR_NONE);
}
   
/*--------------- O u t p u t ( ) ---------------*/


void Output (void *data)
{
        CPU_INT08U n = 0;
	OS_ERR		osErr;			      /* -- uCos Error Code */   
        OS_MSG_SIZE msgSize;          /* -- Size of received message */
	PBuffer		*fBfr = NULL;	      /* -- Current output buffer */
	/* Task runs forever, or until preempted or suspended. */
	for(;;)
	  {
            /* If no output buffer is assigned, get one from the output queue. */
            if (fBfr == NULL)
              {
                 fBfr =  OSQPend(&FramerQueue,
                                  0,
                                  OS_OPT_PEND_BLOCKING,
                                  &msgSize,
                                  NULL,
                                  &osErr);
                  assert(osErr==OS_ERR_NONE);
                  //i=0;
              }
            framer = (Framer *) fBfr->bfr;
            switch(framer->Type)
            {
            case 0x0b://error case sending to ctrlctr
                PutByte(0x03);
                PutByte(0xAF);
                PutByte(0xEF);
                PutByte(0x09);
                PutByte(0x01);
                PutByte(0x02);
                PutByte(0x0B);
                PutByte(framer->Dta[0]);
                n = 0x03 ^ 0xAF ^ 0xEF ^ 0x09 ^ 0x01 ^ 0x02 ^ 0x0B ^ framer->Dta[0];
                PutByte(n);
                TxFlush();
                break;
            case 0x0A://sending acknowledgement to ctrlctr
                PutByte(0x03);
                PutByte(0xAF);
                PutByte(0xEF);
                PutByte(0x9);
                PutByte(0x1);
                PutByte(0x2);
                PutByte(0xA);
                PutByte(framer->Dta[0]);
                n = 0x03 ^ 0xAF ^ 0xEF ^ 0x09 ^ 0x01 ^ 0x02 ^ 0xa ^ framer->Dta[0];
                PutByte(n);
                TxFlush();
                break;
            case 0x07://sending step command to robot
                PutByte(0x03);
                PutByte(0xAF);
                PutByte(0xEF);
                PutByte(0x9);
                PutByte(framer->Dta[1]);
                PutByte(0x2);
                PutByte(0x7);
                PutByte(framer->Dta[0]);
                n = 0x03 ^ 0xAF ^ 0xEF ^ 0x09 ^ framer->Dta[1] ^ 0x02 ^ 0x7 ^ framer->Dta[0];
                PutByte(n);
                TxFlush();
                break;
            }
            Free(fBfr);
            fBfr = NULL;
          }
}
