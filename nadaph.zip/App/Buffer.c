/*-------------------------Buffer.c----------------------*/

/*      Purpose: Initialization of function prototypes for buffers in buffer pair 
                  required to input-output data from RS232
*/

#include <stdio.h>
#include "includes.h"
#include "Buffer.h"

#define nul 0

/*intialize the buffer*/
void BfrInit(Buffer *bfr, CPU_INT08U *bfrSpace, CPU_INT16U Size)
{
    bfr->buffer = bfrSpace;
    bfr->size = Size;
    bfr->putIndex = nul;
    bfr->getIndex = nul;
    bfr->closed = FALSE;
}

/*reset a buffer*/
void BfrReset(Buffer *bfr)
{
    bfr->putIndex = nul;
    bfr->getIndex = nul;
    bfr->closed = FALSE;
}

/*tests whether the buffer is close*/
CPU_BOOLEAN BfrClosed(Buffer *bfr)
{
    if (bfr->closed== TRUE)
      return TRUE;
    else
      return FALSE;
}

/*mark the buffer closed*/
void BfrClose (Buffer *bfr)
{
    bfr->closed = TRUE;
}

/*mark the buffer open*/
void BfrOpen (Buffer *bfr)
{
    bfr->closed = FALSE;
}

/*test whether buffer is full*/
CPU_BOOLEAN BfrFull (Buffer *bfr)
{
    if (bfr->putIndex >= bfr->size)
      return TRUE;
    else
      return FALSE;
}

/*test whether buffer is empty*/
CPU_BOOLEAN BfrEmpty (Buffer *bfr)
{
    if (bfr->getIndex >= bfr->putIndex)
      return TRUE;
    else
      return FALSE;
}

/*add a byte to buffer at address given by putIndex
  and increament putIndex by 1, also, close the buffer
  if full*/
CPU_INT16S BfrAddByte (Buffer *bfr, CPU_INT16S theByte)
{
    if(bfr->closed==FALSE)
    {
        bfr->buffer[bfr->putIndex] = theByte;
        bfr->putIndex = bfr->putIndex + 1;       //not sure about this part
        if (bfr->putIndex >= bfr->size)
          bfr->closed = TRUE;
        else
            bfr->closed = FALSE;
        
        return (theByte) ;              //not sure about this part
    }
    else
      return -1;
}

/*return the byte from getIndex position*/
CPU_INT16S BfrNextByte (Buffer *bfr)
{
    if(bfr->closed==TRUE)
    {
        return (bfr->buffer[bfr->getIndex]);
    }
    else
        return -1;
}

/*return the byte from position getIndex and increament 
  the getIndex by 1, also, mark open if empty*/
CPU_INT16S BfrRemByte (Buffer *bfr)
{
    CPU_INT16S b;
    if(bfr->closed==TRUE)
    {
        b = bfr->buffer[bfr->getIndex];
        bfr->getIndex = bfr->getIndex +1;
        if(bfr->getIndex >= bfr->putIndex)
            bfr->closed = FALSE;
/*        else
          bfr->closed = TRUE;*/
        return b;
    }
    else
        return -1;
}