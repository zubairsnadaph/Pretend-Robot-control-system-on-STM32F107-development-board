/*-------------------RobotCtl.c-------------------*/
/*
PURPOSE
Create Packets of Robot command message (step, follow or loop) based on message type.
*/

#include "RobotCtl.h"
#include "includes.h"
#include "assert.h"
#include "MemMgr.h"
#include "Globals.h"
#include "RobotMgr.h"
#include "framer.h"
#include "PktParser.h"
/* Size of the Process task stack */
#define	PROCESS_STK_SIZE     256 
#define RobotPrio 1

OS_Q	RobotQueue[16];
OS_Q    producerMbox[16];
// Process Task Control Block
static OS_TCB robotTCB[16];
/* Stack space for Process task stack */
static CPU_STK		RobotStk[16][PROCESS_STK_SIZE];
//OS_MUTEX Mutex;

//CPU_BOOLEAN stop;
CPU_INT08U retry;
CPU_INT08U presentvalues[16][2];
static locationofbot bot[16];
CPU_BOOLEAN stop[16];
//static   CPU_INT08U addrr;

//PBuffer		*iBfr = NULL;	/* -- Current input buffer */
//PBuffer		*frBfr = NULL;	/* -- Current output buffer */
//PBuffer		*MBfr = NULL;	/* -- Current output buffer */


/*----- f u n c t i o n    p r o t o t y p e s -----*/
CPU_VOID RobotCtrl(CPU_VOID *data);
void MovetoPos(CPU_INT08U addr,CPU_INT08U xPosition,CPU_INT08U yPosition);
void updateHere(CPU_INT08U address,CPU_INT08U x,CPU_INT08U y);
CPU_INT08U nextstep(CPU_INT08U X,CPU_INT08U Y, CPU_INT08S xdiff, CPU_INT08S ydiff);

/*------------------- create robot control task------------------------*/
void CreateRbtCtrlTask(locationofbot pmessage)
{
	OS_ERR		osErr;/* -- OS Error code */
  
        OSQCreate(&RobotQueue[pmessage.address], "Robot Queue", PoolSize, &osErr);
	assert(osErr == OS_ERR_NONE);
        
        OSQCreate(&producerMbox[pmessage.address], "Producer Mailbox", 1, &osErr);
        assert(osErr == OS_ERR_NONE);

	/* Create Process task. */	
  OSTaskCreate(&robotTCB[pmessage.address],
               "Managing Task",
               RobotCtrl, 
               &pmessage,
               RobotPrio,
               &RobotStk[pmessage.address][0],
               PROCESS_STK_SIZE / 10,
               PROCESS_STK_SIZE,
               0,
               0,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);
  assert(osErr == OS_ERR_NONE);
  bot[pmessage.address].xLocation= pmessage.xLocation;
  bot[pmessage.address].yLocation= pmessage.yLocation;
}

/*--------------- C t l  P r o c e s s ( ) ---------------*/

CPU_VOID RobotCtrl(CPU_VOID *data)
{
	OS_ERR		  osErr;			/* -- OS Error code */
        msg *rmsg;
        locationofbot robot = *(locationofbot *)data;
        OS_MSG_SIZE msgSize;    /* -- Received message size */
        PBuffer *iBfr = NULL;
	//CPU_INT08U addrr;
        //robot = (msg *)data;
        //addrr=robot->Data[0];
	/* Task runs forever, or until preempted or suspended. */
	for(;;)
	{
		// If input buffer is not assigned, get a filled buffer from the input queue. 
		if (iBfr == NULL)
			{
                          iBfr =  OSQPend(&RobotQueue[robot.address],
                                          0,
                                          OS_OPT_PEND_BLOCKING,
                                          &msgSize,
                                          NULL,
                                          &osErr);
                          assert(osErr==OS_ERR_NONE);
			}
		rmsg = (msg *) iBfr->bfr;
                
                switch(rmsg->MsgType)
                {
                case 0x00://system reset case
                  NVIC_GenerateCoreReset();
                  break;
                case 0x02://move to a location case
                  bot[rmsg->Data[0]].nextX= rmsg->Data[1];
                  bot[rmsg->Data[0]].nextY= rmsg->Data[2];
                  MovetoPos(rmsg->Data[0],rmsg->Data[1],rmsg->Data[2]);                  
                  break;
                case 0x03://follow a path case
                  for(CPU_INT08U g=1;g<=rmsg->Payloadlen-5;g+=2)
                  {
                    MovetoPos(rmsg->Data[0],rmsg->Data[g],rmsg->Data[g+1]);
                  }
                  break;
                case 0x4://loop case
                  while(!stop[robot.address])
                  {
                    for(CPU_INT08U g=1;g<=rmsg->Payloadlen-5;g+=2)
                    {
                      MovetoPos(rmsg->Data[0],rmsg->Data[g],rmsg->Data[g+1]);
                    }
                  }
                  stop[robot.address]=FALSE;
                  break;
               /* case 0x5://stop case
                  stop[rmsg->Data[0]]=TRUE;
                  break;*/
		}
		Free(iBfr);
                  iBfr=NULL;
      }
}

void MovetoPos(CPU_INT08U addr,CPU_INT08U xPosition,CPU_INT08U yPosition)
{
  PBuffer *frBfr= NULL;
  OS_ERR osErr;
  while((bot[addr].xLocation != xPosition || bot[addr].yLocation != yPosition)&& !stop[addr])
  {
    if (frBfr == NULL)
      frBfr = Allocate();
    CPU_INT08U currentX = bot[addr].xLocation;
    CPU_INT08U currentY = bot[addr].yLocation;
    CPU_INT08S xdifference = xPosition-currentX;
    CPU_INT08S ydifference = yPosition-currentY;
    OSMutexPend(&Mutex,NULL,OS_OPT_PEND_BLOCKING,NULL,&osErr);
    CPU_INT08U d = nextstep(currentX,currentY,xdifference,ydifference);
    AddByte(frBfr,0x07);
    AddByte(frBfr,d);
    AddByte(frBfr,addr);
    OSQPost(&FramerQueue, frBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
    assert(osErr==OS_ERR_NONE);
    frBfr = NULL;    
    if(d!=0)
      Factory[currentX][currentY]=0;
    else
      retry++;
    updateHere(addr,currentX,currentY);
    OSMutexPost(&Mutex, OS_OPT_POST_NONE, &osErr);
    if(retry>=10)
    {
      if (frBfr == NULL)
        frBfr = Allocate();
      stop[addr] = TRUE;
      AddByte(frBfr,0x10|addr);
      AddByte(frBfr, 0x0B);
      OSQPost(& FramerQueue, frBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
      assert(osErr==OS_ERR_NONE);
      frBfr = NULL;
      retry=0;
    }
  }
}

void updateHere(CPU_INT08U address,CPU_INT08U x,CPU_INT08U y)
{
  PBuffer *MBfr = NULL;
  OS_ERR osErr;
  OS_MSG_SIZE msgSize;
  Robotpkt *here;
  //message->MsgType=0x09;
  if(MBfr==NULL)
  {
    MBfr =  OSQPend(&producerMbox[address],
                                          0,
                                          OS_OPT_PEND_BLOCKING,
                                          &msgSize,
                                          NULL,
                                          &osErr);
                          assert(osErr==OS_ERR_NONE);
  }
  here = (Robotpkt *) MBfr->bfr;
  if(here->type==0x09)
  {
    bot[address].xLocation= here->Dat[0];
    bot[address].yLocation= here->Dat[1];
    Factory[bot[address].xLocation][bot[address].yLocation]=1;
  }
  if(here->type==0x05)
  {
    stop[address]=TRUE;
  }
  //OSQPost(&producerMbox[message->Data[0]], MBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
  Free(MBfr);
  MBfr=NULL;
}

CPU_INT08U nextstep(CPU_INT08U X,CPU_INT08U Y, CPU_INT08S xdiff, CPU_INT08S ydiff)
{
  CPU_INT08U direction;
  if(xdiff>0 && ydiff>0)
  {
    if(Factory[X+1][Y+1]==0)
        direction=2;
      else if(Factory[X][Y+1]==0)
        direction=1;
      else if(Factory[X-1][Y+1]==0)
        direction=8;
      else if(Factory[X-1][Y]==0)
        direction=7;
      else if(Factory[X+1][Y]==0)
        direction=3;
      else if(Factory[X][Y-1]==0)
        direction=5;
      else if(Factory[X-1][Y-1]==0)
        direction=6;
      else if(Factory[X+1][Y-1]==0)
        direction=4;
      else
        direction=0;
  }
  else if(xdiff<0 && ydiff>0)
  {
     if(Factory[X-1][Y+1]==0)
        direction=8;
      else if(Factory[X][Y+1]==0)
        direction=1;
      else if(Factory[X-1][Y]==0)
        direction=7;
      else if(Factory[X+1][Y+1]==0)
        direction=2;
      else if(Factory[X-1][Y-1]==0)
        direction=6;
      else if(Factory[X+1][Y]==0)
        direction=3;
      else if(Factory[X][Y-1]==0)
        direction=5;
      else if(Factory[X+1][Y-1]==0)
        direction=4;
      else
        direction=0;
  }  
  else if(xdiff<0 && ydiff<0)
  {
    if(Factory[X-1][Y-1]==0)
        direction=6;
      else if(Factory[X-1][Y]==0)
        direction=7;
      else if(Factory[X][Y-1]==0)
        direction=5;
      else if(Factory[X+1][Y-1]==0)
        direction=4;
      else if(Factory[X+1][Y]==0)
        direction=3;
      else if(Factory[X-1][Y+1]==0)
        direction=8;
      else if(Factory[X][Y+1]==0)
        direction=1;
      else if(Factory[X+1][Y+1]==0)
        direction=2;
      else
        direction=0;
  }  
  else if(xdiff>0 && ydiff<0)
  {
   if(Factory[X+1][Y-1]==0)
        direction=4;
      else if(Factory[X][Y-1]==0)
        direction=5;
      else if(Factory[X+1][Y]==0)
        direction=3;
      else if(Factory[X-1][Y-1]==0)
        direction=6;
      else if(Factory[X-1][Y]==0)
        direction=7;
      else if(Factory[X+1][Y+1]==0)
        direction=2;
      else if(Factory[X][Y+1]==0)
        direction=1;
      else if(Factory[X-1][Y+1]==0)
        direction=8;
      else
        direction=0;
  }
  else if(xdiff>0 && ydiff==0)
  {
    if(Factory[X+1][Y]==0)
      direction=3;
    else if(Factory[X+1][Y+1]==0)
      direction=2;
    else if(Factory[X+1][Y-1]==0)
      direction=4;
    else if(Factory[X][Y+1]==0)
      direction=1;
    else if(Factory[X][Y-1]==0)
      direction=5;
    else if(Factory[X-1][Y+1]==0)
      direction=8; 
    else if(Factory[X-1][Y]==0)
      direction=7;
    else if(Factory[X-1][Y-1]==0)
      direction=6;
    else
      direction=0;
  }
  else if(xdiff<0 && ydiff==0)
  {
    if(Factory[X-1][Y]==0)
      direction=7;
    else if(Factory[X-1][Y+1]==0)
      direction=8; 
    else if(Factory[X-1][Y-1]==0)
      direction=6;
    else if(Factory[X][Y+1]==0)
      direction=1;
    else if(Factory[X][Y-1]==0)
      direction=5;
    else if(Factory[X+1][Y+1]==0)
      direction=2;
    else if(Factory[X+1][Y]==0)
      direction=3;
    else if(Factory[X+1][Y-1]==0)
      direction=4;
    else
      direction=0;
  }
  else if(xdiff==0 && ydiff>0)
  {
    if(Factory[X][Y+1]==0)
      direction=1;
    else if(Factory[X+1][Y+1]==0)
      direction=2;
    else if(Factory[X-1][Y]==0)
      direction=8;
    else if(Factory[X-1][Y]==0)
      direction=7;
    else if(Factory[X+1][Y]==0)
      direction=3;
    else if(Factory[X][Y-1]==0)
      direction=5;
    else if(Factory[X-1][Y-1]==0)
      direction=6;
    else if(Factory[X+1][Y-1]==0)
      direction=4;
    else
      direction=0;
  }
  else if(xdiff==0 && ydiff<0)
  {
    if(Factory[X][Y-1]==0)
      direction=5;
    else if(Factory[X-1][Y-1]==0)
      direction=6;
    else if(Factory[X+1][Y-1]==0)
      direction=4;
    else if(Factory[X-1][Y]==0)
      direction=7;
    else if(Factory[X+1][Y]==0)
      direction=3;
    else if(Factory[X-1][Y+1]==0)
      direction=8;
    else if(Factory[X][Y+1]==0)
      direction=1;
    else if(Factory[X+1][Y+1]==0)
      direction=2;
    else
      direction=0;
  }
  return direction ;
}