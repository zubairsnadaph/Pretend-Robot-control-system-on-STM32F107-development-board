/*--------------------------------RobotMgr.h----------------------*/
#ifndef RobotMgr_H
#define RobotMgr_H

//#include "Framer.h"
#include "includes.h"
#include "RobotCtl.h"
#define maximum 13
#define robotsize 16

/*----- s t r u c t u r e -----*/
typedef struct
{
  CPU_INT08U Payloadlen;
  CPU_INT08U Dest;
  CPU_INT08U Source;
  CPU_INT08U MsgType;
  CPU_INT08U Data[5];
}msg;

/*--------------function prototypes--------------*/
extern CPU_INT08U Factory[39][19];
extern CPU_INT08U Robotupdate[robotsize];
extern OS_MUTEX Mutex;
CPU_VOID CreateRobotMgrTask(CPU_VOID);
void RobotMgr (void *data);
void PostAck(CPU_INT08U vl);


#endif