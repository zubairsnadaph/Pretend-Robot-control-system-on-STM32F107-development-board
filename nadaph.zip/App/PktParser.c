/*----------------PktParser.c-------------------*/
/*  Zubair Nadaph*/
/*Purpose : Receive packet of data, extract payload and forward to 
            Robot Mgr queue for Robot Mgr module. */

#include "PktParser.h"
#include "includes.h"
#include "MemMgr.h"
#include "Globals.h"
//----- c o n s t a n t    d e f i n i t i o n s -----
#define p1Char 0x03
#define p2Char 0xaF
#define p3Char 0xeF
#define Header 5
#define Length 8
#define checkSumbit 0
#define ParserPrio 6 // Parser task priority

/* Size of the Process task stack */
#define	PARSER_STK_SIZE     256 

/*----- g l o b a l s -----*/
// Process Task Control Block
static OS_TCB parserTCB;
OS_Q	ParserQueue;
OS_Q    FramerQueue;

/* Stack space for Process task stack */
static CPU_STK parserStk[PARSER_STK_SIZE];
typedef enum  {p1,p2,p3,L,D,C,Er} parserstate;//Packet Parser states

/*----- C r e a t e P a r s e r T a s k ( ) -----

PURPOSE
Create and initialize the Parser Task.
*/
CPU_VOID CreateParserTask(CPU_VOID)
{
  OS_ERR		osErr;/* -- OS Error code */
  
  /* Create Parser task. */	
  OSTaskCreate(&parserTCB,
               "Processing Task",
               ParsePkt, 
               NULL,
               ParserPrio,
               &parserStk[0],
               PARSER_STK_SIZE / 10,
               PARSER_STK_SIZE,
               0,
               100,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);
  assert(osErr == OS_ERR_NONE);
  OSQCreate(&ParserQueue, "Parser Queue",PoolSize, &osErr);
   assert(osErr == OS_ERR_NONE);
   
   OSQCreate(&FramerQueue, "Framer Queue",PoolSize, &osErr);
   assert(osErr == OS_ERR_NONE);
}

//-----ParsePkt()------
//purpose:Takes the packet and puts the payload in robot mgr queue
CPU_VOID ParsePkt(CPU_VOID *data)
{
  PBuffer *iBfr = NULL;
  static  parserstate  parsestate=p1;
  CPU_INT16S  c;
  CPU_INT08U i=0;
  CPU_INT08U checkSum;
  for(;;)
  {
    c = GetByte();
     if (iBfr == NULL)
     iBfr = Allocate();
    if(c>=0)
    {  
      switch(parsestate)
      {
      case p1://checks for preamble 1
        if(c == p1Char) 
        {
          parsestate = p2;
          checkSum = c;
        } 
        else
        {
           Error(1); 
          parsestate=Er;
        }
        break;
      case p2:  //checks for preamble 2
        if(c == p2Char) 
        {
          parsestate=p3;
          checkSum=checkSum^c;
        }
        else
        {
            Error(2); 
          parsestate = Er;
        }
        break;
      case p3:  //checks for preamble 3
        if(c == p3Char) 
        {
          parsestate=L ;
          checkSum=checkSum^c;
        }
        else
        {
           Error(3); 
          parsestate = Er;
        }
        break;
      case L:   //checks for packet length
        if(c<Length)
        {
           AddByte(iBfr,4); 
          parsestate=Er;
        }
        else
        {
          AddByte(iBfr, (c - Header));    
          checkSum=checkSum^c;
          parsestate = D;
          i=0;
        }
        break;
      case D:   //transfers payload to robot mgr queue
        i++; 
        AddByte(iBfr,c);   
        checkSum=checkSum^c;
        if(i >= iBfr->bfr[0])
        {
          parsestate = C;
        }      
        break;
      case C:   //checks for incorrect checksum
        checkSum=checkSum^c;
        if(checkSum==checkSumbit)
        {
          parsestate=p1;
          OS_ERR osErr;
          OSQPost(&ParserQueue, iBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
          assert(osErr==OS_ERR_NONE);
          // Indicate that a new input buffer is needed.
          iBfr = NULL; 
  
        }
        else
        {
           AddByte(iBfr,5); 
          parsestate=Er;
        }
        break;
      case Er:
        if(c==p1Char)        /*it checks for p1 and p2 sync bytes and if found goes to case p3 */
        {
          checkSum=c;
          c = GetByte();
          if(c>0)
          {
            if(c==p2Char)
            {
              parsestate=p3;
              checkSum=checkSum^c; 
            }
          }
        }
        break;
      }  
    }
  }
}
//------------Error()---------
void Error(CPU_INT08U ErrorNumber)
{
    PBuffer *iBfr = NULL;
   if (iBfr == NULL)
     iBfr = Allocate();
   AddByte(iBfr,0x0B);
  AddByte(iBfr,ErrorNumber);
  OS_ERR osErr;
  OSQPost(&FramerQueue,iBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
  assert(osErr==OS_ERR_NONE);
  iBfr=NULL;
}