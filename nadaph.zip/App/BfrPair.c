/*--------------------BfrPair.c---------------------*/
#include "includes.h"
#include "BfrPair.h"

#define zero 0
#define one 1

/*initializing the buffer pairs*/
void BfrPairInit(BfrPair *bfrPair, CPU_INT08U *bfr0Space, CPU_INT08U *bfr1Space, CPU_INT16U sizee)
{
    bfrPair->putBfrNum = zero;
    BfrInit(&bfrPair-> buffers[zero], bfr0Space, sizee);
    BfrInit(&bfrPair-> buffers[one], bfr1Space, sizee);
}

/*reset the put buffer*/
void PutBfrReset(BfrPair *bfrPair)
{
    BfrReset(&bfrPair->buffers[bfrPair->putBfrNum]);
}

/*obtain the address of put buffers data space*/
CPU_INT08U *PutBfrAddr(BfrPair *bfrPair){
    return (bfrPair->buffers[bfrPair->putBfrNum].buffer);//skeptical
}

/*obtain the address of the get buffer's data space*/
CPU_INT08U *GetBfrAddr(BfrPair *bfrPair){
    return (bfrPair->buffers[1-bfrPair->putBfrNum].buffer);//skeptical
}

/*tests whether putbuffer is closed*/
CPU_BOOLEAN PutBfrClosed(BfrPair *bfrPair)
{
    return (BfrClosed(&bfrPair->buffers[bfrPair->putBfrNum]));
}

/*test whether getbuffer is closed*/
CPU_BOOLEAN GetBfrClosed(BfrPair *bfrPair)
{
    return (BfrClosed(&bfrPair->buffers[1-bfrPair->putBfrNum]));
}

/*mark the put buffer closed*/
void PutBfrClose(BfrPair *bfrPair)
{
    BfrClose (&bfrPair->buffers[bfrPair->putBfrNum]);
}

/*mark the get buffer open*/
void GetBfrOpen(BfrPair *bfrPair)
{
    BfrOpen (&bfrPair->buffers[1-bfrPair->putBfrNum]);
}

/*add a byte to put buffer--increament the putIndex of putbuffer by 1
  --close the buffer if full*/
CPU_INT16S PutBfrAddByte(BfrPair *bfrPair, CPU_INT16S byte)
{
    return (BfrAddByte (&bfrPair->buffers[bfrPair->putBfrNum],byte));
}

/*return the byte from position getIndex from getbuffer--
  return -ve if no data*/
CPU_INT16S GetBfrNextByte(BfrPair *bfrPair)
{
    return (BfrNextByte (&bfrPair->buffers[1-bfrPair->putBfrNum]));
}

/*return byte from get buffer at getIndex--increament the getIndex of 
  getbuffer by 1 --open the buffer if no data*/
CPU_INT16S GetBfrRemByte(BfrPair *bfrPair)
{
    return (BfrRemByte (&bfrPair->buffers[1-bfrPair->putBfrNum]));
}

/*test whether the two buffers are ready to be swapped
  and return TRUE if ready*/
CPU_BOOLEAN BfrPairSwappable(BfrPair *bfrPair)
{
  if (PutBfrClosed(bfrPair))
  {
      if (!(GetBfrClosed(bfrPair)))
        return TRUE;
      else
        return FALSE;
  }
  else
    return FALSE;
}

/* swapping the buffers*/
void BfrPairSwap(BfrPair *bfrPair)
{
    bfrPair->putBfrNum = 1-bfrPair->putBfrNum;
    PutBfrReset(bfrPair);
}

CPU_BOOLEAN PutBfrEmpty(BfrPair *bfrPair)
{
    return(BfrEmpty(&bfrPair->buffers[bfrPair->putBfrNum]));
}