/*----------------------------RobotCtl.h-----------------------------*/
#ifndef RobotCtl_H
#define RobotCtl_H
//#include "cpu.h"
#include <includes.h>
#include "RobotMgr.h"

typedef struct
{
  CPU_INT08U type;
  CPU_INT08U Dat[1];
}Robotpkt;

typedef struct
{
  CPU_INT08U address;
  CPU_INT08U xLocation;
  CPU_INT08U yLocation;
  CPU_INT08U nextX;
  CPU_INT08U nextY;
}locationofbot;

extern OS_Q RobotQueue[16];
extern OS_Q producerMbox[16];
extern OS_MUTEX Mutex;
CPU_VOID CreateRbtCtrlTask(locationofbot pmessage);
#endif