/*=============== P k t P a r s e r . h ===============
BY:	 Zubair Nadaph
PURPOSE
This is the interface to the module PktParser.c.
*/

#ifndef PKTPARSER_H
#define PKTPARSER_H

#include "includes.h"
#include "BfrPair.h"
#include "RobotMgr.h"
#include "SerIODriver.h"
#include "assert.h"

extern OS_Q FramerQueue;
extern OS_Q ParserQueue;

//----- f u n c t i o n    p r o t o t y p e s -----
CPU_VOID CreateParserTask(CPU_VOID);
CPU_VOID ParsePkt(CPU_VOID *data);
void Error(CPU_INT08U ErrorNum);
#endif







