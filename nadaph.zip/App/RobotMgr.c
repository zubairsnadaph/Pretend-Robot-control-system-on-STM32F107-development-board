/*-----------------------RobotMgr.c---------------------------*/
/*      Written By: Zubair Nadaph               */

/*
PURPOSE
Get filled input buffers from the parser queue, decode into message, 
and send filled output buffers to respective robot queue;
*/

#include "RobotMgr.h"
#include "assert.h"
#include "Globals.h"
#include "PBuffer.h"
#include "MemMgr.h"
#include "RobotCtl.h"
#include "PktParser.h"
/* Size of the Process task stack */
#define	PROCESS_STK_SIZE     600 
#define MgrPrio 2

msg *message;
CPU_INT08U Robotupdate[robotsize];
CPU_INT08U Factory[39][19];
static CPU_INT08U errcnt;
locationofbot currentrobot;

static OS_TCB MgrTCB;
OS_MUTEX Mutex;

/* Stack space for Process task stack */
static CPU_STK		MgrStk[PROCESS_STK_SIZE];

/*----- f u n c t i o n    p r o t o t y p e s -----*/

void PosttoRbtCtl(PBuffer *bfr, CPU_INT08U ad);
void PosttoRbtHere(CPU_INT08U type, CPU_INT08U S, CPU_INT08U x, CPU_INT08U y);


/*--------------- C r e a t e P r o c e s s T a s k ( ) ---------------*/

/*
PURPOSE
Create and initialize the RobotMgr task.
*/
void CreateRobotMgrTask(void)
{
	OS_ERR		osErr;/* -- OS Error code */
        OSMutexCreate(&Mutex,"Floor Ctrl",&osErr);
        assert(osErr==OS_ERR_NONE);

	/* Create Process task. */	
  OSTaskCreate(&MgrTCB,
               "Managing Task",
               RobotMgr, 
               NULL,
               MgrPrio,
               &MgrStk[0],
               PROCESS_STK_SIZE / 10,
               PROCESS_STK_SIZE,
               0,
               0,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);
  assert(osErr == OS_ERR_NONE);
}

/*--------------- M g r  P r o c e s s ( ) ---------------*/

void RobotMgr (void *data)
{
	OS_ERR		  osErr;			/* -- OS Error code */
        OS_MSG_SIZE msgSize;    /* -- Received message size */
        PBuffer *iBfr = NULL;
	
	/* Task runs forever, or until preempted or suspended. */
	for(;;)
	{
		/* If input buffer is not assigned, get a filled buffer from the parser queue. */
		if (iBfr == NULL)
			{
                          iBfr =  OSQPend(&ParserQueue,
                                          0,
                                          OS_OPT_PEND_BLOCKING,
                                          &msgSize,
                                          NULL,
                                          &osErr);
                          assert(osErr==OS_ERR_NONE);
			}
                
                message = (msg *)iBfr->bfr;               
                
                switch (message->MsgType)
                {
                case 0x1://add robot case
                  if(message->Data[0]>2 && message->Data[0]<16)
                  {
                    if(Robotupdate[message->Data[0]]!=1)
                    {
                      if(Factory[message->Data[1]][message->Data[2]]!=1)
                      {
                        if(message->Data[1]<40 && message->Data[2]<19)
                        {
                          currentrobot.address=message->Data[0];
                          currentrobot.xLocation=message->Data[1];
                          currentrobot.yLocation=message->Data[2];
                          CreateRbtCtrlTask(currentrobot);
                          //PosttoRbtCtl();
                          Factory[message->Data[1]][message->Data[2]]=1;
                          Robotupdate[message->Data[0]]=1;
                          PostAck(message->MsgType);
                          //message->MsgType=0x09;
                        }
                        else
                          Error(12);
                      }
                      else
                        Error(13);
                    }
                    else
                      Error(14);
                  }
                  else
                    Error(11);
                  Free(iBfr);
                  //iBfr = NULL; 
                 break;
                case 0x2://move robot case
                  if(message->Data[0]>2 && message->Data[0]<16)
                  {
                    if(Robotupdate[message->Data[0]]==1)
                    {
                      if(message->Data[1]<40 && message->Data[2]<19)
                      {
                        PosttoRbtCtl(iBfr,message->Data[0]);
                        PostAck(message->MsgType);                        
                        //iBfr = NULL;
                        //PosttoRbtHere();
                        //message->MsgType=0x09;
                      }
                      else
                        Error(23);
                    }
                    else
                      Error(22);
                  }
                  else
                    Error(21);                  
                  break;
                case 0x3://follow path case
                  if(message->Data[0]>2 && message->Data[0]<16)
                  {
                      if(Robotupdate[message->Data[0]]==1)
                    {                      
                      /*while(message->Data[g]<39 && message->Data[g+1]<18)
                      {
                        errcnt++;
                        g+=2;
                      }*/
                      CPU_INT08U g;
                      for(g=1;g<=(message->Payloadlen)-5;g+=2)
                      {if(message->Data[g]>39 || message->Data[g+1]>18)
                      {
                        errcnt++;
                      }}
                      if(errcnt!=0)
                      {
                        Error(33);
                      }
                      else
                      {
                        PosttoRbtCtl(iBfr,message->Data[0]);
                        PostAck(message->MsgType);
                        //Free(iBfr);
                      }
                      errcnt = 0;
                      g=0;
                    }
                    else
                      Error(32);
                  }
                  else
                    Error(31);
                  break;
                case 0x4://loop case
                  if(message->Data[0]>2 && message->Data[0]<16)
                  {
                      if(Robotupdate[message->Data[0]]==1)
                    {
                      for(CPU_INT08U g=1;g<=message->Payloadlen-5;g+=2)
                      {
                        if(message->Data[g]>39 && message->Data[g+1]>18)
                          errcnt++;
                      }
                      if(errcnt!=0)
                      {
                        Error(43);
                      }
                      else
                      {
                        PosttoRbtCtl(iBfr,message->Data[0]);
                        PostAck(message->MsgType);
                      }
                    }
                    else
                      Error(42);
                  }
                  else
                    Error(41);
                  break;
                case 0x05://stop looping case
                  if(message->Data[0]>2 && message->Data[0]<16)
                  {
                    if(Robotupdate[message->Data[0]]==1)
                    {
                      PosttoRbtHere(message->MsgType,message->Data[0], message->Data[0],message->Data[0]);
                      PostAck(message->MsgType);
                    }
                    else
                      Error(52);
                  }
                  else
                    Error(51); 
                  //Free(iBfr);
                  break;
                case 0x09:
                  PosttoRbtHere(message->MsgType,message->Source,message->Data[0],message->Data[1]);
                  Free(iBfr);
                  break;
                }
                //Free(iBfr);
                iBfr=NULL;
                
	}
}
      
void PostAck(CPU_INT08U vl)
{
  PBuffer *oBfr = NULL;
  OS_ERR osErr;
  if (oBfr == NULL)
     oBfr = Allocate();
  AddByte(oBfr,0x0A);
  AddByte(oBfr,vl);
  OSQPost(&FramerQueue, oBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
          assert(osErr==OS_ERR_NONE);
  oBfr = NULL;
}

void PosttoRbtCtl(PBuffer *bfr, CPU_INT08U ad)
{
    OS_ERR		osErr;
    OSQPost(&RobotQueue[ad], bfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
      assert(osErr==OS_ERR_NONE);      
      //Free(bfr);
      //bfr = NULL;      
      //cBfr = NULL;
}
                                 
void PosttoRbtHere(CPU_INT08U type, CPU_INT08U S, CPU_INT08U x, CPU_INT08U y)
{
  PBuffer *pBfr=NULL;
  OS_ERR		osErr;
  
  if (pBfr == NULL)
     pBfr = Allocate();
  switch(type)
  {
  case 0x09:
    AddByte(pBfr,0x09);
    AddByte(pBfr,x);
    AddByte(pBfr,y);
    OSQPost(&producerMbox[S], pBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
    assert(osErr==OS_ERR_NONE);
    break;
  case 0x05:
    AddByte(pBfr,0x05);
    OSQPost(&producerMbox[S], pBfr, sizeof(PBuffer), OS_OPT_POST_FIFO, &osErr);
    assert(osErr==OS_ERR_NONE);
    break;
  }
    //pBfr = NULL;
    //Free(iBfr);
      //iBfr = NULL;    
}